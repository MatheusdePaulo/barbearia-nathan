<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barber Nathan | Estilo e Tradição</title>

    <!-- Fontes do Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@800&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        [x-cloak] { display: none !important; }
        .text-outline {
            -webkit-text-stroke: 1px #FFFFFF;
            color: transparent;
        }
    </style>
</head>
<body class="font-work-sans antialiased text-zinc-900 bg-[#F8F5EF]">

<div class="relative w-full">
    <!-- NAVBAR -->
    <div class="absolute top-0 left-0 w-full z-[100]">
        <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <main>
        <!-- HERO -->
        <?php echo $__env->make('partials.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- PROFISSIONAL -->
        <?php echo $__env->make('partials.professional', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- SERVIÇOS -->
        <?php echo $__env->make('partials.services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- CTA -->
        <?php echo $__env->make('partials.cta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- PRODUCTS -->
        <?php echo $__env->make('partials.products', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- PORQUE NOS ESCOLHER -->
        <?php echo $__env->make('partials.why-choose-us', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- O Footer entra por último, contendo o agendamento e o mapa -->
        <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </main>
</div>

</body>
</html>
<?php /**PATH /home/matheus-ubuntu/barbearia-nathan/resources/views/welcome.blade.php ENDPATH**/ ?>