<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barber Nathan | Agendar Horário</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body { background-color: #050505; color: white; font-family: 'Inter', sans-serif; }
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
            cursor: pointer;
        }
        /* Custom scrollbar para a lista de serviços */
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: #121212; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #D4AF37; border-radius: 10px; }
    </style>
</head>
<body class="flex min-h-screen">

<aside class="w-[320px] bg-[#121212] border-r border-zinc-800 p-8 hidden md:block flex-shrink-0">
    <div class="mb-10 flex justify-center">
        <img src="<?php echo e(asset('images/logotipo_nathan.png')); ?>" alt="Barber Nathan" class="w-40 h-auto">
    </div>
    <nav class="space-y-4">
        <a href="<?php echo e(url('/')); ?>" class="block px-4 py-3 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all italic font-medium">← Voltar ao Início</a>

        <div class="pt-10">
            <button class="w-full py-4 bg-zinc-800 text-white font-bold uppercase rounded-lg border border-zinc-700 hover:bg-zinc-700 transition-all text-sm tracking-widest">
                Cortes Antigos
            </button>
        </div>
    </nav>
</aside>

<main class="flex-1 p-6 md:p-12 overflow-y-auto">
    <header class="mb-10">
        <span class="text-[#D4AF37] font-bold uppercase tracking-widest text-xs">Confirmar Agendamento</span>
        <h2 class="text-4xl font-bold italic mt-2">Agendamento Geral</h2>
        <p class="text-zinc-500 mt-2">Selecione o serviço, data e horário desejados.</p>
    </header>

    <form action="<?php echo e(route('appointments.store')); ?>" method="POST" class="max-w-7xl">
        <?php echo csrf_field(); ?>

        <div class="grid grid-cols-1 xl:grid-cols-2 gap-16">

            <!-- COLUNA ESQUERDA: SELEÇÃO DE SERVIÇOS -->
            <div class="space-y-6">
                <label class="block text-zinc-400 text-sm font-bold mb-4 uppercase tracking-wide italic">1. Escolha o Serviço</label>

                <div class="space-y-3 pr-2 max-h-[650px] overflow-y-auto custom-scroll">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="relative flex items-center justify-between bg-[#121212] border border-zinc-800 p-5 rounded-xl cursor-pointer group transition-all hover:border-[#D4AF37]/30">
                            <input type="radio" name="service_id" value="<?php echo e($s->id); ?>" class="hidden peer" required
                                <?php echo e((isset($service) && $service->id == $s->id) ? 'checked' : ''); ?>>

                            <div class="flex items-center gap-5">
                                <div class="relative w-16 h-16 shrink-0 bg-white rounded-lg overflow-hidden border border-zinc-700 flex items-center justify-center">
                                    <img src="<?php echo e(asset('images/' . $s->image)); ?>"
                                         alt="<?php echo e($s->name); ?>"
                                         class="w-full h-full object-contain p-2 transition-all duration-500">
                                </div>

                                <div>
                                    <p class="text-[#D4AF37] font-barlow font-extrabold uppercase text-base tracking-tight group-hover:text-white transition-colors leading-tight">
                                        <?php echo e($s->name); ?>

                                    </p>
                                    <p class="text-zinc-500 text-xs font-medium">
                                        R$ <?php echo e(number_format($s->price, 2, ',', '.')); ?> | <?php echo e($s->duration ?? '30'); ?>min
                                    </p>
                                </div>
                            </div>

                            <!-- INDICADOR CIRCULAR COM BOLA INTERNA CORRETA -->
                            <div class="w-7 h-7 border-2 border-zinc-800 rounded-full flex items-center justify-center peer-checked:border-[#D4AF37] transition-all duration-300">
                                <div class="w-3.5 h-3.5 bg-[#D4AF37] rounded-full opacity-0 scale-50 peer-checked:opacity-100 peer-checked:scale-100 transition-all duration-300 shadow-[0_0_10px_rgba(212,175,55,0.4)]"></div>
                            </div>

                            <!-- Borda de destaque externa -->
                            <div class="absolute inset-0 border-2 border-transparent peer-checked:border-[#D4AF37] rounded-xl pointer-events-none transition-all duration-300"></div>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- COLUNA DIREITA: DATA E HORA -->
            <div class="space-y-10">

                <!-- Card Cliente -->
                <div class="bg-[#121212] border border-zinc-800 p-6 rounded-2xl border-l-4 border-l-[#D4AF37]">
                    <p class="text-zinc-500 text-xs uppercase font-bold tracking-wider mb-2">Cliente Logado</p>
                    <h4 class="text-xl font-bold text-white uppercase"><?php echo e(auth()->user()->name); ?></h4>
                    <p class="text-zinc-400 text-sm mt-1 italic">WhatsApp: <?php echo e(auth()->user()->phone ?? 'Não cadastrado'); ?></p>
                </div>

                <!-- 2. DATA -->
                <div>
                    <label class="block text-zinc-400 text-sm font-bold mb-4 uppercase tracking-wide">2. Escolha a Data</label>
                    <input type="date" name="date" required
                           class="w-full bg-[#121212] border border-zinc-800 rounded-xl p-4 focus:border-[#D4AF37] outline-none transition-all text-lg font-bold"
                           value="<?php echo e(date('Y-m-d')); ?>" min="<?php echo e(date('Y-m-d')); ?>">
                </div>

                <!-- 3. HORÁRIO -->
                <div>
                    <label class="block text-zinc-400 text-sm font-bold mb-4 uppercase tracking-wide">3. Selecione o Horário</label>
                    <div class="grid grid-cols-4 gap-3">
                        <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="cursor-pointer group">
                                <input type="radio" name="time" value="<?php echo e($slot); ?>" class="hidden peer" required>
                                <div class="bg-[#121212] border border-zinc-800 p-3 rounded-lg text-center transition-all peer-checked:bg-[#D4AF37] peer-checked:text-black peer-checked:border-[#D4AF37] group-hover:border-[#D4AF37]/50 font-bold text-sm">
                                    <?php echo e($slot); ?>

                                </div>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- SINAL DE RESERVA E BOTÃO -->
                <div class="space-y-6">
                    <div class="p-6 border border-[#D4AF37]/20 bg-[#D4AF37]/5 rounded-2xl flex items-start gap-4">
                        <div class="bg-[#D4AF37]/10 p-2 rounded-lg text-[#D4AF37]">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div>
                            <h4 class="text-[#D4AF37] font-bold text-sm uppercase">Sinal de Reserva: R$ 5,00</h4>
                            <p class="text-xs text-zinc-500 mt-1 leading-relaxed">
                                O sinal será descontado do valor total no dia do atendimento.
                            </p>
                        </div>
                    </div>

                    <button type="submit" class="w-full py-5 bg-[#D4AF37] text-black font-black uppercase rounded-xl shadow-2xl shadow-[#D4AF37]/20 hover:bg-[#f3ca4a] hover:-translate-y-1 transition-all tracking-widest">
                        Confirmar e Gerar Pix
                    </button>
                </div>

            </div>
        </div>
    </form>
</main>

</body>
</html>
<?php /**PATH /home/matheus-ubuntu/barbearia-nathan/resources/views/appointments/create.blade.php ENDPATH**/ ?>