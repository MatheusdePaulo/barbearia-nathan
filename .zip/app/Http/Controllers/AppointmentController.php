<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AppointmentController extends Controller
{
    /**
     * Exibe a lista de agendamentos (opcional para o admin)
     */
    public function index()
    {
        $appointments = Appointment::with('service')->get();
        return view('admin.appointments.index', compact('appointments'));
    }

    /**
     * Método para o Nathan fazer o AGENDAMENTO AVULSO na Agenda
     */
    public function storeAvulso(Request $request)
    {
        $validated = $request->validate([
            'client_name' => 'required|string|max:255',
            'service_id'  => 'required|exists:services,id',
            'date'        => 'required|date',
            'time'        => 'required',
        ]);

        try {
            Appointment::create([
                'user_id'     => null, // Nulo pois é um cliente avulso/sem cadastro
                'client_name' => $validated['client_name'],
                'service_id'  => $validated['service_id'],
                'date'        => $validated['date'],
                'time'        => $validated['time'],
                'status'      => 'confirmed', // Agendamento manual já entra confirmado
            ]);

            return redirect()->back()->with('success', 'Agendamento avulso registrado!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Erro ao salvar: ' . $e->getMessage());
        }
    }

    /**
     * Método padrão para o CLIENTE agendar pelo site/app
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'date'       => 'required|date|after_or_equal:today',
            'time'       => 'required',
        ]);

        Appointment::create([
            'user_id'    => Auth::id(),
            'service_id' => $validated['service_id'],
            'date'       => $validated['date'],
            'time'       => $validated['time'],
            'status'     => 'pending', // Cliente agendando fica como pendente
        ]);

        return redirect()->route('dashboard')->with('success', 'Agendamento solicitado!');
    }

    /**
     * Atualiza o status de um agendamento (Confirmar, Concluir, Cancelar)
     */
    public function updateStatus(Request $request, $id)
    {
        $appointment = Appointment::findOrFail($id);
        $appointment->update(['status' => $request->status]);

        return redirect()->back()->with('success', 'Status atualizado!');
    }

    public function destroy($id)
    {
        $appointment = Appointment::findOrFail($id);
        $appointment->delete();

        return redirect()->back()->with('success', 'Agendamento removido.');
    }
}
